# Profiles Library 2.0

Decaid plugin for profile discovery and import.

- Offline: Decaid bundled defaults + release snapshot profiles included in this ZIP.
- Online: refreshes public GitHub profile directories and the curated Decent community URLs.
- Installed skins: best-effort scan of common profile manifest paths.
- Legacy TCL: settings_2a (pressure), settings_2b (flow), settings_2c/settings_2c2 (advanced).
- Import only: does not activate, edit, delete, or upload a profile to the machine.
